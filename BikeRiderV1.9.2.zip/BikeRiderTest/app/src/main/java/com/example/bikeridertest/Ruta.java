package com.example.bikeridertest;

import java.io.Serializable;

public class Ruta implements Serializable {
    private int id;
    private String titulo;
    private double distancia; // en kilómetros
    private long tiempo; // en milisegundos
    private double calorias; // calorías quemadas
    private String fechaInicio;
    private String fechaFin;

    // Constructor
    public Ruta(int id, String titulo, double distancia, long tiempo, double calorias, String fechaInicio, String fechaFin) { // Cambié int calorias a double
        this.id = id;
        this.titulo = titulo;
        this.distancia = distancia;
        this.tiempo = tiempo;
        this.calorias = calorias;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
    }

    // Getters
    public int getId() {
        return id;
    }

    public String getTitulo() {
        return titulo;
    }

    public double getDistancia() {
        return distancia;
    }

    public long getTiempo() {
        return tiempo;
    }

    public double getCalorias() {
        return calorias;
    }

    public String getFechaInicio() {
        return fechaInicio;
    }

    public String getFechaFin() {
        return fechaFin;
    }
}




