

package com.example.bikeridertest;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import com.google.android.gms.maps.model.LatLng;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;

public class DBHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "BikeRider.db";
    private static final int VERSION = 6;

    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Tabla de usuarios
        db.execSQL("CREATE TABLE users(" +
                "tvgmail TEXT PRIMARY KEY, " +
                "tvcontra TEXT, " +
                "nombre_usuario TEXT, " +
                "imagen_perfil BLOB)");

        // Tabla de recorridos
        db.execSQL("CREATE TABLE Recorridos(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "usuario_id TEXT, " + // Nuevo campo para el identificador del usuario
                "nombre TEXT, " +
                "calorias REAL, " + // Cambiado de INTEGER a REAL para permitir decimales
                "distancia REAL, " +
                "fecha_inicio TEXT, " +
                "fecha_fin TEXT, " +
                "FOREIGN KEY(usuario_id) REFERENCES users(tvgmail))"); // Añadimos la clave foránea

        // Tabla de puntos de cada recorrido
        db.execSQL("CREATE TABLE Ciclovias(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "recorrido_id INTEGER, " +
                "lat REAL, " +
                "lng REAL, " +
                "orden INTEGER, " +
                "FOREIGN KEY(recorrido_id) REFERENCES Recorridos(id))");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // se eliminar y se vuelven a crear las tablas si sumamos un numero
        db.execSQL("DROP TABLE IF EXISTS Ciclovias");
        db.execSQL("DROP TABLE IF EXISTS Recorridos");
        db.execSQL("DROP TABLE IF EXISTS users");
        onCreate(db);
    }

    public Usuario obtenerUsuario(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        Usuario usuario = null;

        try {
            cursor = db.rawQuery("SELECT nombre_usuario, imagen_perfil FROM users WHERE tvgmail = ?", new String[]{email});
            if (cursor.moveToFirst()) {
                String nombreUsuario = cursor.getString(0);
                byte[] imagenBytes = cursor.getBlob(1);
                Bitmap imagenPerfil = null;

                if (imagenBytes != null) {
                    imagenPerfil = BitmapFactory.decodeByteArray(imagenBytes, 0, imagenBytes.length);
                }

                usuario = new Usuario(email, nombreUsuario, imagenPerfil);
            }
        } finally {
            if (cursor != null) {
                cursor.close();
            }
            db.close();
        }

        return usuario;
    }

    public boolean actualizarUsuario(String email, String nombreUsuario, Bitmap imagenPerfil) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("nombre_usuario", nombreUsuario); //Solo un nombre de usuario para cada cuenta

        if (imagenPerfil != null) {
            ByteArrayOutputStream stream = new ByteArrayOutputStream();
            imagenPerfil.compress(Bitmap.CompressFormat.PNG, 100, stream);
            byte[] imagenBytes = stream.toByteArray();
            values.put("imagen_perfil", imagenBytes);
        }

        int rows = db.update("users", values, "tvgmail = ?", new String[]{email});
        db.close();

        return rows > 0;
    }

    // Método para insertar un nuevo recorrido
    public void insertarRecorrido(String usuarioId, String nombre, List<LatLng> puntos, double calorias, double distanciaKm, String fechaInicio, String fechaFin) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.beginTransaction();
        try {
            // Insertar en la tabla Recorridos
            ContentValues recorridoValues = new ContentValues();
            recorridoValues.put("usuario_id", usuarioId);
            recorridoValues.put("nombre", nombre);
            recorridoValues.put("calorias", calorias);
            recorridoValues.put("distancia", distanciaKm);
            recorridoValues.put("fecha_inicio", fechaInicio);
            recorridoValues.put("fecha_fin", fechaFin);
            long recorridoId = db.insert("Recorridos", null, recorridoValues);

            // Insertar los puntos en la tabla Ciclovias
            for (int i = 0; i < puntos.size(); i++) {
                LatLng punto = puntos.get(i);
                ContentValues values = new ContentValues();
                values.put("recorrido_id", recorridoId);
                values.put("lat", punto.latitude);
                values.put("lng", punto.longitude);
                values.put("orden", i);
                db.insert("Ciclovias", null, values);
            }
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
            db.close();
        }
    }

    // Método para obtener los recorridos de un usuario específico
    public List<RutaCompleta> obtenerRutas(String usuarioId) {
        SQLiteDatabase db = this.getReadableDatabase();
        List<RutaCompleta> rutas = new ArrayList<>();
        Cursor cursorRecorridos = null;
        try {
            cursorRecorridos = db.rawQuery("SELECT id, nombre, calorias, distancia, fecha_inicio, fecha_fin FROM Recorridos WHERE usuario_id = ?", new String[]{usuarioId});
            if (cursorRecorridos.moveToFirst()) {
                do {
                    int recorridoId = cursorRecorridos.getInt(0);
                    String nombreRuta = cursorRecorridos.getString(1);
                    double calorias = cursorRecorridos.getDouble(2);
                    double distancia = cursorRecorridos.getDouble(3);
                    String fechaInicio = cursorRecorridos.getString(4);
                    String fechaFin = cursorRecorridos.getString(5);
                    List<LatLng> rutaPuntos = obtenerPuntosRecorrido(recorridoId);

                    rutas.add(new RutaCompleta(recorridoId, nombreRuta, rutaPuntos, calorias, distancia, fechaInicio, fechaFin));
                } while (cursorRecorridos.moveToNext());
            }
        } finally {
            if (cursorRecorridos != null) {
                cursorRecorridos.close();
            }
            db.close();
        }
        return rutas;
    }

    // Método para obtener los puntos de un recorrido específico
    public List<LatLng> obtenerPuntosRecorrido(int recorridoId) {
        List<LatLng> ruta = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        try {
            cursor = db.rawQuery("SELECT lat, lng FROM Ciclovias WHERE recorrido_id = ? ORDER BY orden", new String[]{String.valueOf(recorridoId)});
            while (cursor.moveToNext()) {
                double lat = cursor.getDouble(0);
                double lng = cursor.getDouble(1);
                ruta.add(new LatLng(lat, lng));
            }
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        return ruta;
    }

    // Método para insertar un nuevo usuario
    public Boolean insertData(String tvgmail, String tvcontra) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("tvgmail", tvgmail);
        values.put("tvcontra", tvcontra);

        long result = db.insert("users", null, values);
        db.close();
        return result != -1;
    }

    // Método para verificar si el correo ya existe en la base de datos
    public Boolean checktvgmail(String tvgmail) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM users WHERE tvgmail=?", new String[]{tvgmail});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        db.close();
        return exists;
    }

    public Boolean checktvgmailtvcontra(String tvgmail, String tvcontra) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM users WHERE tvgmail=? AND tvcontra=?", new String[]{tvgmail, tvcontra});
        boolean valid = cursor.getCount() > 0;
        cursor.close();
        db.close();
        return valid;
    }
}
