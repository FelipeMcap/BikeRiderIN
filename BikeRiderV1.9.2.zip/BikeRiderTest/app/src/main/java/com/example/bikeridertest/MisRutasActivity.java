package com.example.bikeridertest;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.maps.model.LatLng;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MisRutasActivity extends AppCompatActivity {

    private RecyclerView recyclerViewRutas;
    private RutaAdapter rutaAdapter;
    private DBHelper dbHelper;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mis_rutas);

        recyclerViewRutas = findViewById(R.id.recyclerViewRutas);
        recyclerViewRutas.setLayoutManager(new LinearLayoutManager(this));

        dbHelper = new DBHelper(this);

        List<Ruta> rutas = obtenerRutasDesdeDB();
        rutaAdapter = new RutaAdapter(this, rutas, new RutaAdapter.OnRutaClickListener() {
            @Override
            public void onRutaClick(Ruta ruta) {
                Intent intent = new Intent(MisRutasActivity.this, DetalleRutaActivity.class);
                intent.putExtra("ruta", ruta);
                startActivity(intent);
            }
        });

        recyclerViewRutas.setAdapter(rutaAdapter);
    }

    private List<Ruta> obtenerRutasDesdeDB() {
        // Obtener el usuario actual
        SharedPreferences preferences = getSharedPreferences("userSession", MODE_PRIVATE);
        String userEmail = preferences.getString("userEmail", null);
        if (userEmail == null) {
            Toast.makeText(this, "Error: Usuario no identificado", Toast.LENGTH_SHORT).show();
            return new ArrayList<>();
        }

        List<RutaCompleta> rutasCompletas = dbHelper.obtenerRutas(userEmail);
        List<Ruta> rutas = new ArrayList<>();

        for (RutaCompleta rutaCompleta : rutasCompletas) {
            int id = rutaCompleta.getId();
            String nombreRuta = rutaCompleta.getNombre();
            List<LatLng> rutaLatLng = rutaCompleta.getPuntos();
            double calorias = rutaCompleta.getCalorias();
            double distancia = rutaCompleta.getDistancia();
            String fechaInicio = rutaCompleta.getFechaInicio();
            String fechaFin = rutaCompleta.getFechaFin();

            // Calcula el tiempo en milisegundos
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault());
            long tiempo = 0;
            try {
                Date inicio = sdf.parse(fechaInicio);
                Date fin = sdf.parse(fechaFin);
                tiempo = fin.getTime() - inicio.getTime();
            } catch (ParseException e) {
                e.printStackTrace();
            }

            Ruta ruta = new Ruta(id, nombreRuta, distancia, tiempo, calorias, fechaInicio, fechaFin);
            rutas.add(ruta);
        }

        return rutas;
    }

    public void atras2(View v) {
        Intent intent = new Intent(MisRutasActivity.this,MapaBR.class);
        startActivity(intent);
        finish();
    }


}

