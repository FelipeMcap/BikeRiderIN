package com.example.bikeridertest;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.content.SharedPreferences;


public class MainActivity extends AppCompatActivity {


    EditText tvgmail,tvcontra;
    Button loguear;
    DBHelper DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        tvgmail=findViewById(R.id.tvgmail);
        tvcontra=findViewById(R.id.tvcontra);
        loguear=findViewById(R.id.loguear);
        DB= new DBHelper(this);

        loguear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String user = tvgmail.getText().toString();
                String pass = tvcontra.getText().toString();

                if (TextUtils.isEmpty(user) || TextUtils.isEmpty(pass)) {
                    Toast.makeText(MainActivity.this, "Todos los campos son obligatorios", Toast.LENGTH_SHORT).show();
                } else {
                    Boolean checkuserpass = DB.checktvgmailtvcontra(user, pass);
                    if (checkuserpass == true) {
                        Toast.makeText(MainActivity.this, "Logueo Exitoso", Toast.LENGTH_SHORT).show();

                        // Guardar el correo electrónico del usuario en SharedPreferences
                        SharedPreferences preferences = getSharedPreferences("userSession", MODE_PRIVATE);
                        SharedPreferences.Editor editor = preferences.edit();
                        editor.putString("userEmail", user); // 'user' es el correo electrónico ingresado
                        editor.apply();

                        Intent intent = new Intent(getApplicationContext(), MapaBR.class);
                        startActivity(intent);
                        finish(); // Cierra la actividad actual para que el usuario no pueda volver con el botón 'Atrás'
                    } else {
                        Toast.makeText(MainActivity.this, "Logueo Fallido", Toast.LENGTH_SHORT).show();
                    }


                }
            }
        });



        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    public void regis(View v) {
        Intent intent = new Intent(MainActivity.this, Registrarse.class);
        startActivity(intent);
    }
}