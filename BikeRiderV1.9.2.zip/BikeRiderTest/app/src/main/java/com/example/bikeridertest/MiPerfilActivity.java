package com.example.bikeridertest;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

public class MiPerfilActivity extends AppCompatActivity {

    private static final int REQUEST_IMAGE_CAPTURE = 1;
    private static final int REQUEST_IMAGE_PICK = 2;


    private ImageView ivProfilePicture;
    private Button btnCalculateBMI, btnSaveChanges;
    private TextView btnLogout;
    private EditText etUsername;

    private DBHelper dbHelper;

    private String userEmail;
    private String username;
    private Bitmap profilePicture;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mi_perfil);

        // Inicializar vistas
        ivProfilePicture = findViewById(R.id.ivProfilePicture);
        btnCalculateBMI = findViewById(R.id.btnCalculateBMI);
        btnLogout = findViewById(R.id.btnLogout);
        btnSaveChanges = findViewById(R.id.btnSaveChanges);
        etUsername = findViewById(R.id.etUsername);

        dbHelper = new DBHelper(this);

        SharedPreferences preferences = getSharedPreferences("userSession", MODE_PRIVATE);
        userEmail = preferences.getString("userEmail", null);

        if (userEmail == null) {
            Toast.makeText(this, "Error: Usuario no identificado", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        cargarDatosUsuario();

        ivProfilePicture.setOnClickListener(v -> elegirImagen());

        btnCalculateBMI.setOnClickListener(v -> {
            Intent intent = new Intent(MiPerfilActivity.this, CalculadoraIMCActivity.class);
            startActivity(intent);
        });

        btnSaveChanges.setOnClickListener(v -> guardarCambios());

        btnLogout.setOnClickListener(v -> cerrarSesion());
    }

    private void cargarDatosUsuario() {
        Usuario usuario = dbHelper.obtenerUsuario(userEmail);
        if (usuario != null) {
            username = usuario.getNombreUsuario();
            profilePicture = usuario.getImagenPerfil();

            etUsername.setText(username);
            if (profilePicture != null) {
                ivProfilePicture.setImageBitmap(profilePicture);
            } else {
                ivProfilePicture.setImageResource(R.mipmap.iconv1);
            }
        }
    }

    private void elegirImagen() {
        // Opción de seleccionar entre Cámara o Galería
        CharSequence[] opciones = {"Tomar foto", "Elegir de la galería", "Cancelar"};

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Selecciona una opción");
        builder.setItems(opciones, (dialog, item) -> {
            if (opciones[item].equals("Tomar foto")) {
                Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
                    startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
                }
            } else if (opciones[item].equals("Elegir de la galería")) {
                Intent pickPhotoIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(pickPhotoIntent, REQUEST_IMAGE_PICK);
            } else if (opciones[item].equals("Cancelar")) {
                dialog.dismiss();
            }
        });
        builder.show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK) {
            if (requestCode == REQUEST_IMAGE_CAPTURE) {
                Bundle extras = data.getExtras();
                profilePicture = (Bitmap) extras.get("data");
                ivProfilePicture.setImageBitmap(profilePicture);
            } else if (requestCode == REQUEST_IMAGE_PICK && data != null) {
                Uri selectedImageUri = data.getData();
                try {
                    profilePicture = MediaStore.Images.Media.getBitmap(this.getContentResolver(), selectedImageUri);
                    ivProfilePicture.setImageBitmap(profilePicture);
                } catch (IOException e) {
                    e.printStackTrace();
                    Toast.makeText(this, "Error al cargar la imagen", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }


    private void cerrarSesion() {
        SharedPreferences preferences = getSharedPreferences("userSession", MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.clear();
        editor.apply();

        Intent intent = new Intent(this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    public void atras4(View v) {
        Intent intent = new Intent(MiPerfilActivity.this, MapaBR.class);
        startActivity(intent);
        finish();
    }

    private void guardarCambios() {
        String nuevoNombreUsuario = etUsername.getText().toString().trim();

        if (nuevoNombreUsuario.isEmpty()) {
            Toast.makeText(this, "Por favor ingrese un nombre de usuario", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean resultado = dbHelper.actualizarUsuario(userEmail, nuevoNombreUsuario, profilePicture);

        if (resultado) {
            // Guardar la imagen de perfil en SharedPreferences
            SharedPreferences preferences = getSharedPreferences("userProfile", MODE_PRIVATE);
            SharedPreferences.Editor editor = preferences.edit();

            // Convierte la imagen a base64 para almacenarla como String
            if (profilePicture != null) {
                ByteArrayOutputStream stream = new ByteArrayOutputStream();
                profilePicture.compress(Bitmap.CompressFormat.PNG, 100, stream);
                String profileImageBase64 = Base64.encodeToString(stream.toByteArray(), Base64.DEFAULT);
                editor.putString("profileImage", profileImageBase64);
            }
            editor.apply();

            Toast.makeText(this, "Datos actualizados correctamente", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Error al actualizar los datos", Toast.LENGTH_SHORT).show();
        }
    }

}

