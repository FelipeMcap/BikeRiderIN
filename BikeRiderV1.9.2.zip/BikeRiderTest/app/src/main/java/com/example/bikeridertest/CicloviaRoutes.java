package com.example.bikeridertest;

import android.graphics.Color;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.PolylineOptions;

public class CicloviaRoutes {
    private GoogleMap mMap;

    public CicloviaRoutes(GoogleMap googleMap) {
        this.mMap = googleMap;
    }

    public void agregarRutasCiclovia() {
        // Ruta 1
        PolylineOptions cicloviaRuta1 = new PolylineOptions()
                .add(new LatLng(-33.4416202, -70.6591153)) //INICIO: DIECIOCHO , TERMINO: AGUSTINAS
                .add(new LatLng(-33.442739, -70.658920))
                .add(new LatLng(-33.443060, -70.659023))
                .add(new LatLng(-33.445735, -70.658518))
                .add(new LatLng(-33.446157, -70.658394))
                .add(new LatLng(-33.449832, -70.657570))
                .add(new LatLng(-33.452634, -70.657014))
                .width(10)
                .color(Color.GREEN);
        mMap.addPolyline(cicloviaRuta1);

        // Ruta 2
        PolylineOptions cicloviaRuta2 = new PolylineOptions()
                .add(new LatLng(-33.441643, -70.669941)) //INICIO: HUERFANOS TERMINO: HUERFANOS
                .add(new LatLng(-33.441054, -70.665036))
                .add(new LatLng(-33.440587, -70.660507))
                .width(10)
                .color(Color.GREEN);
        mMap.addPolyline(cicloviaRuta2);

        // Ruta 3
        PolylineOptions cicloviaRuta3 = new PolylineOptions()
                .add(new LatLng(-33.414268, -70.729253)) //INICIO: AV.Costanera Sur TERMINO: Vitacura
                .add(new LatLng(-33.414369, -70.726384))
                .add(new LatLng(-33.413171, -70.723324))
                .add(new LatLng(-33.412557, -70.721527))
                .add(new LatLng(-33.412333, -70.720835))
                .add(new LatLng(-33.411254, -70.720181))
                .add(new LatLng(-33.411198, -70.718443))
                .add(new LatLng(-33.410954, -70.717346))
                .add(new LatLng(-33.410891, -70.715412))
                .add(new LatLng(-33.409861, -70.713786))
                .add(new LatLng(-33.408340, -70.711995))
                .add(new LatLng(-33.408501, -70.707689))
                .add(new LatLng(-33.409184, -70.702940))
                .add(new LatLng(-33.412250, -70.698658))
                .add(new LatLng(-33.413912, -70.696845))
                .add(new LatLng(-33.415995, -70.693328))
                .add(new LatLng(-33.421088, -70.686159))
                .add(new LatLng(-33.423847, -70.683007))
                .add(new LatLng(-33.425316, -70.680298))
                .add(new LatLng(-33.428262, -70.671924))
                .add(new LatLng(-33.430666, -70.664146))
                .add(new LatLng(-33.430346, -70.662209))
                .add(new LatLng(-33.431090, -70.659018))
                .add(new LatLng(-33.431439, -70.656132))
                .add(new LatLng(-33.435392, -70.639312))
                .add(new LatLng(-33.436270, -70.635491))
                .add(new LatLng(-33.435735, -70.635312))
                .add(new LatLng(-33.435402, -70.632827))
                .add(new LatLng(-33.431532, -70.626461))
                .add(new LatLng(-33.431768, -70.626101))
                .add(new LatLng(-33.429010, -70.623796))
                .add(new LatLng(-33.429068, -70.623490))
                .add(new LatLng(-33.424763, -70.621500))
                .add(new LatLng(-33.423747, -70.620108))
                .add(new LatLng(-33.421763, -70.614323))
                .add(new LatLng(-33.416477, -70.607373))
                .add(new LatLng(-33.414614, -70.605914))
                .add(new LatLng(-33.411050, -70.605576))
                .add(new LatLng(-33.410674, -70.605640))
                .add(new LatLng(-33.405900, -70.603800))
                .add(new LatLng(-33.403858, -70.603033))
                .add(new LatLng(-33.396759, -70.603470))
                .add(new LatLng(-33.392730, -70.601251))
                .add(new LatLng(-33.390859, -70.599160)) //FIN
                .width(7)
                .color(Color.GREEN);
        mMap.addPolyline(cicloviaRuta3);



        // Ruta 4
        PolylineOptions cicloviaRuta4 = new PolylineOptions()
                .add(new LatLng(-33.485795, -70.748530))
                .add(new LatLng(-33.485307, -70.748010))
                .add(new LatLng(-33.485246, -70.747992))
                .add(new LatLng(-33.485127, -70.747835))
                .add(new LatLng(-33.484812, -70.747531))
                .add(new LatLng(-33.484367, -70.747112))
                .add(new LatLng(-33.484271, -70.746972))
                .add(new LatLng(-33.483726, -70.746593))
                .add(new LatLng(-33.483790, -70.746427))
                .add(new LatLng(-33.483699, -70.746354))
                .add(new LatLng(-33.483782, -70.746432))
                .add(new LatLng(-33.480902, -70.744544))
                .add(new LatLng(-33.472617, -70.737894))
                .add(new LatLng(-33.471523, -70.736916))
                .add(new LatLng(-33.471468, -70.736613))
                .add(new LatLng(-33.469453, -70.733423))
                .add(new LatLng(-33.469335, -70.733572))
                .add(new LatLng(-33.469282, -70.733370))
                .add(new LatLng(-33.469087, -70.733124))
                .add(new LatLng(-33.467920, -70.731041))
                .add(new LatLng(-33.467773, -70.731029))
                .add(new LatLng(-33.467529, -70.730492))
                .add(new LatLng(-33.467199, -70.729847))
                .add(new LatLng(-33.466357, -70.728330))
                .add(new LatLng(-33.465666, -70.726982))
                .add(new LatLng(-33.465463, -70.726712))
                .add(new LatLng(-33.465272, -70.726316))
                .add(new LatLng(-33.463254, -70.722260))
                .add(new LatLng(-33.463155, -70.722051))
                .add(new LatLng(-33.463131, -70.721939))
                .add(new LatLng(-33.462281, -70.719981))
                .add(new LatLng(-33.461974, -70.719259))
                .add(new LatLng(-33.461566, -70.718356))
                .add(new LatLng(-33.461334, -70.717787))
                .add(new LatLng(-33.461271, -70.717706))
                .add(new LatLng(-33.459563, -70.713712))
                .add(new LatLng(-33.459309, -70.713370))
                .add(new LatLng(-33.459213, -70.712856))
                .add(new LatLng(-33.458815, -70.712281))
                .add(new LatLng(-33.458738, -70.712359))

                .width(7)
                .color(Color.GREEN);
        mMap.addPolyline(cicloviaRuta4);
    }
}
