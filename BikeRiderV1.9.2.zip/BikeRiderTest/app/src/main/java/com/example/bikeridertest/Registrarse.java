package com.example.bikeridertest;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Registrarse extends AppCompatActivity {

    private EditText tvgmail, tvcontra, tvrepcontra;
    private Button registrarcorreo;
    private DBHelper DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        // Inicializar vistas
        tvgmail = findViewById(R.id.tvgmail);
        tvcontra = findViewById(R.id.tvcontra);
        tvrepcontra = findViewById(R.id.tvrepcontra);
        registrarcorreo = findViewById(R.id.registrarcorreo);

        // Inicializar DBHelper
        DB = new DBHelper(this);

        // Configurar el listener para el botón de registro
        registrarcorreo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String gmail = tvgmail.getText().toString().trim();
                String pass = tvcontra.getText().toString();
                String repass = tvrepcontra.getText().toString();

                if (TextUtils.isEmpty(gmail) || TextUtils.isEmpty(pass) || TextUtils.isEmpty(repass)) {
                    Toast.makeText(Registrarse.this, "Todos los campos son requeridos", Toast.LENGTH_SHORT).show();
                } else {
                    if (pass.equals(repass)) {
                        if (isValidPassword(pass)) {
                            Boolean checkuser = DB.checktvgmail(gmail);
                            if (!checkuser) {
                                Boolean insert = DB.insertData(gmail, pass);
                                if (insert) {
                                    Toast.makeText(Registrarse.this, "Registro Completado Exitosamente", Toast.LENGTH_SHORT).show();

                                    SharedPreferences preferences = getSharedPreferences("userSession", MODE_PRIVATE);
                                    SharedPreferences.Editor editor = preferences.edit();
                                    editor.putString("userEmail", gmail);
                                    editor.apply();

                                    // Navegar directamente a la actividad principal
                                    Intent intent = new Intent(getApplicationContext(), MapaBR.class);
                                    startActivity(intent);
                                    finish(); // Cierra la actividad actual
                                } else {
                                    Toast.makeText(Registrarse.this, "Error al registrar", Toast.LENGTH_SHORT).show();
                                }
                            } else {
                                Toast.makeText(Registrarse.this, "El usuario ya existe", Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            Toast.makeText(Registrarse.this, "La contraseña debe tener al menos 6 caracteres, una mayúscula y un número", Toast.LENGTH_LONG).show();
                        }
                    } else {
                        Toast.makeText(Registrarse.this, "Las contraseñas no coinciden", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }

    private boolean isValidPassword(String password) {
        if (password.length() < 6) {
            return false;
        }

        boolean hasUppercase = false;
        boolean hasNumber = false;

        for (char c : password.toCharArray()) {
            if (Character.isUpperCase(c)) {
                hasUppercase = true;
            }
            if (Character.isDigit(c)) {
                hasNumber = true;
            }

            if (hasUppercase && hasNumber) {
                break;
            }
        }

        return hasUppercase && hasNumber;
    }
}