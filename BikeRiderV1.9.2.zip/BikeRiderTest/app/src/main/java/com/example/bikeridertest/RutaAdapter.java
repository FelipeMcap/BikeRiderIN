package com.example.bikeridertest;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.bikeridertest.R;
import com.example.bikeridertest.Ruta;

import java.util.List;
import java.util.Locale;

public class RutaAdapter extends RecyclerView.Adapter<RutaAdapter.RutaViewHolder> {

    private List<Ruta> rutasList;
    private Context context;
    private OnRutaClickListener listener;

    public RutaAdapter(Context context, List<Ruta> rutasList, OnRutaClickListener listener) {
        this.context = context;
        this.rutasList = rutasList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public RutaViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_ruta, parent, false);
        return new RutaViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RutaViewHolder holder, int position) {

        Ruta ruta = rutasList.get(position);

        holder.tvRutaTitulo.setText(ruta.getTitulo());

        String caloriasFormateadas = String.format(Locale.getDefault(), "%.2f kcal", ruta.getCalorias());
        holder.tvCalorias.setText(caloriasFormateadas);

        String distanciaFormateada = String.format(Locale.getDefault(), "%.2f km", ruta.getDistancia());
        holder.tvDistancia.setText(distanciaFormateada);

        holder.btnVerDetalles.setOnClickListener(v -> {
            if (listener != null) {
                listener.onRutaClick(ruta);
            }
        });

        // Listener para el botón "Eliminar Ruta"
        holder.btnEliminarRuta.setOnClickListener(v -> {
            eliminarRuta(position);
        });
    }

    @Override
    public int getItemCount() {
        return rutasList.size();
    }

    public interface OnRutaClickListener {
        void onRutaClick(Ruta ruta);
    }

    // Método para eliminar una ruta de la lista
    private void eliminarRuta(int position) {
        rutasList.remove(position);
        notifyItemRemoved(position);
        notifyItemRangeChanged(position, rutasList.size());
        Toast.makeText(context, "Ruta eliminada", Toast.LENGTH_SHORT).show();
    }

    public static class RutaViewHolder extends RecyclerView.ViewHolder {
        ImageView imageRutaMapa;
        TextView tvRutaTitulo, tvCalorias, tvDistancia;
        Button btnVerDetalles, btnEliminarRuta;

        public RutaViewHolder(@NonNull View itemView) {
            super(itemView);
            imageRutaMapa = itemView.findViewById(R.id.imageRutaMapa);
            tvRutaTitulo = itemView.findViewById(R.id.tvRutaTitulo);
            tvCalorias = itemView.findViewById(R.id.tvCalorias);
            tvDistancia = itemView.findViewById(R.id.tvDistancia);
            btnVerDetalles = itemView.findViewById(R.id.btnVerDetalles);
            btnEliminarRuta = itemView.findViewById(R.id.btnEliminarRuta); // Referencia al botón "Eliminar Ruta"
        }
    }
}


