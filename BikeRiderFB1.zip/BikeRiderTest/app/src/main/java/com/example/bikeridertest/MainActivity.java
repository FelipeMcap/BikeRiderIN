package com.example.bikeridertest;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.TextUtils;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainActivity extends AppCompatActivity {

    private EditText tvgmail, tvcontra;
    private Button loguear;
    private FirebaseAuth mAuth;
    private ImageView ivTogglePasswordVisibility;
    private boolean isPasswordVisible = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Verificar si la sesión ya está activa
        SharedPreferences preferences = getSharedPreferences("userSession", MODE_PRIVATE);
        boolean sesionIniciada = preferences.getBoolean("sesionIniciada", false);

        if (sesionIniciada) {
            // Redirigir a MapaBR si la sesión está activa
            startActivity(new Intent(this, MapaBR.class));
            finish(); // Finaliza esta actividad para evitar regresar con el botón Atrás
            return;
        }

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            if (checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 101);
            }
        }

        setContentView(R.layout.activity_main);

        tvgmail = findViewById(R.id.tvgmail);
        tvcontra = findViewById(R.id.tvcontra);
        loguear = findViewById(R.id.loguear);
        ivTogglePasswordVisibility = findViewById(R.id.ivTogglePasswordVisibility);

        // Inicializar FirebaseAuth
        mAuth = FirebaseAuth.getInstance();

        // Configurar funcionalidad de mostrar/ocultar contraseña
        ivTogglePasswordVisibility.setOnClickListener(v -> {
            isPasswordVisible = !isPasswordVisible;
            if (isPasswordVisible) {
                tvcontra.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                ivTogglePasswordVisibility.setImageResource(R.mipmap.ojoabierto);
            } else {
                tvcontra.setTransformationMethod(PasswordTransformationMethod.getInstance());
                ivTogglePasswordVisibility.setImageResource(R.mipmap.ojocerrao);
            }
            tvcontra.setSelection(tvcontra.getText().length());
        });

        // Configurar inicio de sesión
        loguear.setOnClickListener(v -> {
            String email = tvgmail.getText().toString();
            String password = tvcontra.getText().toString();

            if (TextUtils.isEmpty(email) || TextUtils.isEmpty(password)) {
                Toast.makeText(MainActivity.this, "Todos los campos son obligatorios", Toast.LENGTH_SHORT).show();
            } else {
                mAuth.signInWithEmailAndPassword(email, password)
                        .addOnCompleteListener(task -> {
                            if (task.isSuccessful()) {
                                FirebaseUser user = mAuth.getCurrentUser();
                                Toast.makeText(MainActivity.this, "Bienvenido " + user.getEmail(), Toast.LENGTH_SHORT).show();

                                SharedPreferences.Editor editor = preferences.edit();
                                editor.putBoolean("sesionIniciada", true);
                                editor.putString("userEmail", user.getEmail());
                                editor.apply();

                                programarNotificaciones(); // Programar notificaciones tras iniciar sesión

                                Intent intent = new Intent(getApplicationContext(), MapaBR.class);
                                startActivity(intent);
                                finish();
                            } else {
                                Toast.makeText(MainActivity.this, "Error: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        });
            }
        });
    }

    private void programarNotificaciones() {
        Intent intent = new Intent(this, NotificationReceiver.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
        long intervalo = 8 * 60 * 60 * 1000; // 8 horas en milisegundos
        long inicio = System.currentTimeMillis() + intervalo;

        if (alarmManager != null) {
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, inicio, intervalo, pendingIntent);
        }
    }

    public void regis(View v) {
        Intent intent = new Intent(MainActivity.this, Registrarse.class);
        startActivity(intent);
    }
}
