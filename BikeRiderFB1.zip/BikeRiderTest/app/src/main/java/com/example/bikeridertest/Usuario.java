package com.example.bikeridertest;

import android.graphics.Bitmap;

public class Usuario {
    private String email;
    private String nombreUsuario;
    private Bitmap imagenPerfil;

    public Usuario(String email, String nombreUsuario, Bitmap imagenPerfil) {
        this.email = email;
        this.nombreUsuario = nombreUsuario;
        this.imagenPerfil = imagenPerfil;
    }

    // Getters y setters
    public String getEmail() {
        return email;
    }

    public String getNombreUsuario() {
        return nombreUsuario;
    }

    public Bitmap getImagenPerfil() {
        return imagenPerfil;
    }

    public void setNombreUsuario(String nombreUsuario) {
        this.nombreUsuario = nombreUsuario;
    }

    public void setImagenPerfil(Bitmap imagenPerfil) {
        this.imagenPerfil = imagenPerfil;
    }
}
