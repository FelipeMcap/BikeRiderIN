package com.example.bikeridertest;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

// Importaciones adicionales
import androidx.appcompat.app.AppCompatActivity;

public class CalculadoraIMCActivity extends AppCompatActivity {

    private EditText etPeso, etAltura;
    private Button btnCalcularIMC;
    private TextView tvResultadoIMC;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculadora_imc);

        // Inicializar vistas
        etPeso = findViewById(R.id.etPeso);
        etAltura = findViewById(R.id.etAltura);
        btnCalcularIMC = findViewById(R.id.btnCalcularIMC);
        tvResultadoIMC = findViewById(R.id.tvResultadoIMC);

        // Configurar el botón
        btnCalcularIMC.setOnClickListener(v -> calcularIMC());
    }

    private void calcularIMC() {
        String pesoStr = etPeso.getText().toString().trim();
        String alturaStr = etAltura.getText().toString().trim();

        if (pesoStr.isEmpty() || alturaStr.isEmpty()) {
            Toast.makeText(this, "Por favor ingrese su peso y altura", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            double peso = Double.parseDouble(pesoStr);
            double altura = Double.parseDouble(alturaStr);

            if (altura <= 0) {
                Toast.makeText(this, "La altura debe ser mayor que cero", Toast.LENGTH_SHORT).show();
                return;
            }

            double imc = peso / (altura * altura);

            String resultado = String.format("Tu IMC es: %.2f", imc);
            tvResultadoIMC.setText(resultado);

        } catch (NumberFormatException e) {
            Toast.makeText(this, "Ingrese valores numéricos válidos", Toast.LENGTH_SHORT).show();
        }
    }

    public void atras(View v) {
        Intent intent = new Intent(CalculadoraIMCActivity.this, MiPerfilActivity.class);
        startActivity(intent);
        finish();
    }
}
