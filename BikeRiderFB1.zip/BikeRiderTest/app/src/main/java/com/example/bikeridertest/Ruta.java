package com.example.bikeridertest;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public class Ruta implements Serializable {
    private String id; // Cambiado a String para almacenar el ID del documento en Firestore
    private String titulo;
    private double distancia; // en kilómetros
    private double calorias; // calorías quemadas
    private String fechaInicio;
    private String fechaFin;
    private List<Map<String, Double>> puntos; // Añadido para almacenar los puntos de la ruta

    // Constructor vacío requerido por Firebase
    public Ruta() {
    }

    // Constructor completo (opcional)
    public Ruta(String id, String titulo, double distancia, double calorias, String fechaInicio, String fechaFin, List<Map<String, Double>> puntos) {
        this.id = id;
        this.titulo = titulo;
        this.distancia = distancia;
        this.calorias = calorias;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
        this.puntos = puntos;
    }

    // Getters y Setters

    public String getId() {
        return id;
    }

    public void setId(String id) { // Añadido setter para id
        this.id = id;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) { // Añadido setter para titulo
        this.titulo = titulo;
    }

    public double getDistancia() {
        return distancia;
    }

    public void setDistancia(double distancia) { // Añadido setter para distancia
        this.distancia = distancia;
    }

    public double getCalorias() {
        return calorias;
    }

    public void setCalorias(double calorias) { // Añadido setter para calorias
        this.calorias = calorias;
    }

    public String getFechaInicio() {
        return fechaInicio;
    }

    public void setFechaInicio(String fechaInicio) { // Añadido setter para fechaInicio
        this.fechaInicio = fechaInicio;
    }

    public String getFechaFin() {
        return fechaFin;
    }

    public void setFechaFin(String fechaFin) { // Añadido setter para fechaFin
        this.fechaFin = fechaFin;
    }

    public List<Map<String, Double>> getPuntos() {
        return puntos;
    }

    public void setPuntos(List<Map<String, Double>> puntos) {
        this.puntos = puntos;
    }
}





