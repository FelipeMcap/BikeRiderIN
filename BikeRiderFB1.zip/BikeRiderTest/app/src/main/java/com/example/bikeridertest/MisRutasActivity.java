package com.example.bikeridertest;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

// Importar Firebase Firestore y Auth
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class MisRutasActivity extends AppCompatActivity {

    private RecyclerView recyclerViewRutas;
    private RutaAdapter rutaAdapter;
    private List<Ruta> rutasList = new ArrayList<>();

    // Variables de Firebase
    private FirebaseFirestore db;
    private String userId;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mis_rutas);

        recyclerViewRutas = findViewById(R.id.recyclerViewRutas);
        recyclerViewRutas.setLayoutManager(new LinearLayoutManager(this));

        rutaAdapter = new RutaAdapter(this, rutasList, ruta -> {
            Intent intent = new Intent(MisRutasActivity.this, DetalleRutaActivity.class);
            intent.putExtra("ruta", ruta);
            startActivity(intent);
        });

        recyclerViewRutas.setAdapter(rutaAdapter);

        db = FirebaseFirestore.getInstance();
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user != null) {
            userId = user.getUid();
            obtenerRutasDesdeFirestore();
        } else {
            Toast.makeText(this, "Usuario no autenticado", Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    private void obtenerRutasDesdeFirestore() {
        db.collection("usuarios").document(userId).collection("rutas")
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        rutasList.clear();
                        for (QueryDocumentSnapshot document : task.getResult()) {
                            Ruta ruta = new Ruta();
                            ruta.setId(document.getId());
                            ruta.setTitulo(document.getString("nombre"));
                            ruta.setDistancia(document.getDouble("distancia"));
                            ruta.setCalorias(document.getDouble("calorias"));
                            ruta.setFechaInicio(document.getString("fechaInicio"));
                            ruta.setFechaFin(document.getString("fechaFin"));
                            ruta.setPuntos((List<Map<String, Double>>) document.get("puntos"));
                            // Puedes calcular el tiempo aquí si es necesario
                            rutasList.add(ruta);
                        }
                        rutaAdapter.notifyDataSetChanged();
                    } else {
                        Toast.makeText(this, "Error al obtener las rutas", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    public void atras2(View v) {
        Intent intent = new Intent(MisRutasActivity.this, MapaBR.class);
        startActivity(intent);
        finish();
    }
}


