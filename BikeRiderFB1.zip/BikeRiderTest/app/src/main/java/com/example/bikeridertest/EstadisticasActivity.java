package com.example.bikeridertest;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class EstadisticasActivity extends AppCompatActivity {

    private ImageView atrass;
    private BarChart barChartCalories, barChartKm;
    private TextView tvTotalCalories, tvTotalKm;
    private FirebaseFirestore db;
    private String userId;
    private Map<Integer, Ruta> rutaDetallesMap; // Mapeo de índice de barra a ruta

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_estadisticas);

        atrass = findViewById(R.id.atrass);
        barChartCalories = findViewById(R.id.barChartCalories);
        barChartKm = findViewById(R.id.barChartKm);
        tvTotalCalories = findViewById(R.id.tvTotalCalories);
        tvTotalKm = findViewById(R.id.tvTotalKm);

        // Configuración del botón de volver
        atrass.setOnClickListener(v -> finish());

        // Inicializar Firebase
        db = FirebaseFirestore.getInstance();
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user != null) {
            userId = user.getUid();
            rutaDetallesMap = new HashMap<>();
            cargarDatosDesdeFirebase();
        } else {
            Toast.makeText(this, "Usuario no autenticado", Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    private void cargarDatosDesdeFirebase() {
        db.collection("usuarios").document(userId).collection("rutas")
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        List<BarEntry> calorieEntries = new ArrayList<>();
                        List<BarEntry> distanceEntries = new ArrayList<>();
                        double totalCalories = 0.0;
                        double totalKm = 0.0;
                        int index = 1;

                        for (QueryDocumentSnapshot document : task.getResult()) {
                            double calorias = document.getDouble("calorias");
                            double distancia = document.getDouble("distancia");
                            String nombre = document.getString("nombre");
                            String fechaInicio = document.getString("fechaInicio");
                            String fechaFin = document.getString("fechaFin");

                            // Crear un objeto Ruta con todos los datos
                            Ruta ruta = new Ruta();
                            ruta.setId(document.getId());
                            ruta.setTitulo(nombre);
                            ruta.setCalorias(calorias);
                            ruta.setDistancia(distancia);
                            ruta.setFechaInicio(fechaInicio);
                            ruta.setFechaFin(fechaFin);

                            // Mapear índice a ruta para mostrar los detalles
                            rutaDetallesMap.put(index, ruta);

                            // Sumar totales
                            totalCalories += calorias;
                            totalKm += distancia;

                            // Añadir datos a los gráficos
                            calorieEntries.add(new BarEntry(index, (float) calorias));
                            distanceEntries.add(new BarEntry(index, (float) distancia));
                            index++;
                        }

                        // Mostrar totales en los TextView
                        tvTotalCalories.setText(String.format(Locale.getDefault(), "%.2f kcal", totalCalories));
                        tvTotalKm.setText(String.format(Locale.getDefault(), "%.2f km", totalKm));

                        // Configurar gráficos
                        configurarGrafico(barChartCalories, calorieEntries, "Calorías Quemadas", getResources().getColor(R.color.blue));
                        configurarGrafico(barChartKm, distanceEntries, "Kilómetros Recorridos", getResources().getColor(R.color.cyan));
                    } else {
                        Toast.makeText(this, "Error al cargar los datos", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void configurarGrafico(BarChart chart, List<BarEntry> entries, String label, int color) {
        BarDataSet dataSet = new BarDataSet(entries, label);
        dataSet.setColor(color);
        dataSet.setValueTextSize(12f);

        BarData barData = new BarData(dataSet);
        chart.setData(barData);

        // Etiquetas del eje X
        String[] labels = new String[entries.size()];
        for (int i = 0; i < entries.size(); i++) {
            labels[i] = "Ruta " + (i + 1);
        }

        XAxis xAxis = chart.getXAxis();
        xAxis.setValueFormatter(new IndexAxisValueFormatter(labels));
        xAxis.setGranularity(1f);
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);

        chart.getAxisLeft().setAxisMinimum(0f);
        chart.getAxisRight().setEnabled(false);
        chart.getDescription().setEnabled(false);
        chart.animateY(1000);

        // Agregar listener de clic en barras
        chart.setOnChartValueSelectedListener(new com.github.mikephil.charting.listener.OnChartValueSelectedListener() {
            @Override
            public void onValueSelected(com.github.mikephil.charting.data.Entry e, com.github.mikephil.charting.highlight.Highlight h) {
                int index = (int) e.getX();
                Ruta ruta = rutaDetallesMap.get(index);
                if (ruta != null) {
                    mostrarDetallesRuta(ruta);
                }
            }

            @Override
            public void onNothingSelected() {
                // No hacer nada
            }
        });
    }


    private void mostrarDetallesRuta(Ruta ruta) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Detalles de la Ruta");

        String mensaje = String.format(Locale.getDefault(),
                "Nombre: %s\nCalorías: %.2f kcal\nDistancia: %.2f km\nFecha Inicio: %s\nFecha Fin: %s",
                ruta.getTitulo(),
                ruta.getCalorias(),
                ruta.getDistancia(),
                ruta.getFechaInicio(),
                ruta.getFechaFin());

        builder.setMessage(mensaje);
        builder.setPositiveButton("Cerrar", (dialog, which) -> dialog.dismiss());
        builder.show();
    }


}



