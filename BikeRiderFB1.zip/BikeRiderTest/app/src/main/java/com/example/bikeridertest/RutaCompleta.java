package com.example.bikeridertest;

import com.google.android.gms.maps.model.LatLng;

import java.util.List;

public class RutaCompleta {
    private int id;
    private String nombre;
    private List<LatLng> puntos;
    private double calorias;
    private double distancia;
    private String fechaInicio;
    private String fechaFin;

    public RutaCompleta(int id, String nombre, List<LatLng> puntos, double calorias, double distancia, String fechaInicio, String fechaFin) {
        this.id = id;
        this.nombre = nombre;
        this.puntos = puntos;
        this.calorias = calorias;
        this.distancia = distancia;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
    }

    // Getters
    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public List<LatLng> getPuntos() {
        return puntos;
    }

    public double getCalorias() { // Cambiado de int a double
        return calorias;
    }

    public double getDistancia() {
        return distancia;
    }

    public String getFechaInicio() {
        return fechaInicio;
    }

    public String getFechaFin() {
        return fechaFin;
    }

}


