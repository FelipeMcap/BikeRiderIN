


package com.example.bikeridertest;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory; // Importar para decodificar Base64
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64; // Importar para codificar y decodificar Base64
import android.util.Log; // Importar Log para depuración
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

// Importaciones de Firebase
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

// Firebase Auth
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
// Firebase Firestore
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.DocumentSnapshot;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class MiPerfilActivity extends AppCompatActivity {

    private static final int REQUEST_IMAGE_CAPTURE = 1;
    private static final int REQUEST_IMAGE_PICK = 2;

    private ImageView ivProfilePicture;
    private Button btnCalculateBMI, btnSaveChanges;
    private TextView btnLogout;
    private EditText etUsername;

    private String userId;
    private String username;
    private Bitmap profilePicture;

    private FirebaseAuth mAuth;
    private FirebaseFirestore db;

    private ProgressDialog progressDialog;

    // TAG para logs
    private static final String TAG = "MiPerfilActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mi_perfil);

        // Inicializar vistas
        ivProfilePicture = findViewById(R.id.ivProfilePicture);
        btnCalculateBMI = findViewById(R.id.btnCalculateBMI);
        btnLogout = findViewById(R.id.btnLogout);
        btnSaveChanges = findViewById(R.id.btnSaveChanges);
        etUsername = findViewById(R.id.etUsername);

        // Inicializar Firebase
        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser != null) {
            userId = currentUser.getUid();
            Log.d(TAG, "Usuario autenticado con UID: " + userId);
        } else {
            Toast.makeText(this, "Usuario no autenticado", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        cargarDatosUsuario();

        ivProfilePicture.setOnClickListener(v -> elegirImagen());

        btnCalculateBMI.setOnClickListener(v -> {
            Intent intent = new Intent(MiPerfilActivity.this, CalculadoraIMCActivity.class);
            startActivity(intent);
        });

        btnSaveChanges.setOnClickListener(v -> guardarCambios());

        btnLogout.setOnClickListener(v -> cerrarSesion());
    }

    private void cargarDatosUsuario() {
        progressDialog = ProgressDialog.show(this, "Cargando", "Por favor espera...", true);
        // Obtener los datos del usuario desde Firestore
        DocumentReference docRef = db.collection("usuarios").document(userId);
        docRef.get().addOnSuccessListener(documentSnapshot -> {
            if (documentSnapshot.exists()) {
                username = documentSnapshot.getString("username");
                etUsername.setText(username);

                String imageBase64 = documentSnapshot.getString("profileImageBase64");
                if (imageBase64 != null) {
                    // Decodificar la imagen desde Base64
                    byte[] decodedString = Base64.decode(imageBase64, Base64.DEFAULT);
                    profilePicture = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
                    ivProfilePicture.setImageBitmap(profilePicture);
                } else {
                    ivProfilePicture.setImageResource(R.mipmap.iconv1);
                }
                progressDialog.dismiss();
            } else {
                // Si el documento no existe, usar valores predeterminados
                ivProfilePicture.setImageResource(R.mipmap.iconv1);
                progressDialog.dismiss();
                Log.d(TAG, "Documento de usuario no existe en Firestore");
            }
        }).addOnFailureListener(e -> {
            Toast.makeText(this, "Error al cargar datos", Toast.LENGTH_SHORT).show();
            progressDialog.dismiss();
            Log.e(TAG, "Error al obtener el documento del usuario", e);
        });
    }

    private void elegirImagen() {
        // Opción de seleccionar entre Cámara o Galería
        CharSequence[] opciones = {"Tomar foto", "Elegir de la galería", "Cancelar"};

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Selecciona una opción");
        builder.setItems(opciones, (dialog, item) -> {
            if (opciones[item].equals("Tomar foto")) {
                Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
                    startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
                }
            } else if (opciones[item].equals("Elegir de la galería")) {
                Intent pickPhotoIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(pickPhotoIntent, REQUEST_IMAGE_PICK);
            } else if (opciones[item].equals("Cancelar")) {
                dialog.dismiss();
            }
        });
        builder.show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // Manejar el resultado de la selección de imagen
        if (resultCode == RESULT_OK) {
            if (requestCode == REQUEST_IMAGE_CAPTURE && data != null) {
                Bundle extras = data.getExtras();
                profilePicture = (Bitmap) extras.get("data");
                ivProfilePicture.setImageBitmap(profilePicture);
            } else if (requestCode == REQUEST_IMAGE_PICK && data != null) {
                Uri selectedImageUri = data.getData();
                try {
                    profilePicture = MediaStore.Images.Media.getBitmap(this.getContentResolver(), selectedImageUri);
                    ivProfilePicture.setImageBitmap(profilePicture);
                } catch (IOException e) {
                    e.printStackTrace();
                    Toast.makeText(this, "Error al cargar la imagen", Toast.LENGTH_SHORT).show();
                    Log.e(TAG, "Error al obtener la imagen desde la galería", e);
                }
            }
        }
    }

    private void cerrarSesion() {
        mAuth.signOut();
        SharedPreferences preferences = getSharedPreferences("userSession", MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.clear();
        editor.apply();

        Intent intent = new Intent(this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    public void atras4(View v) {
        Intent intent = new Intent(MiPerfilActivity.this, MapaBR.class);
        startActivity(intent);
        finish();
    }

    private void guardarCambios() {
        String nuevoNombreUsuario = etUsername.getText().toString().trim();

        if (nuevoNombreUsuario.isEmpty()) {
            Toast.makeText(this, "Por favor ingrese un nombre de usuario", Toast.LENGTH_SHORT).show();
            return;
        }

        progressDialog = ProgressDialog.show(this, "Guardando", "Por favor espera...", true);

        // Preparar los datos para guardar
        DocumentReference userRef = db.collection("usuarios").document(userId);

        // Crear un mapa con los datos a actualizar
        Map<String, Object> updates = new HashMap<>();
        updates.put("username", nuevoNombreUsuario);

        // Si hay una imagen de perfil, convertirla a Base64 y agregarla
        if (profilePicture != null) {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            profilePicture.compress(Bitmap.CompressFormat.JPEG, 50, baos); // Comprimir la imagen
            byte[] imageBytes = baos.toByteArray();
            String imageBase64 = Base64.encodeToString(imageBytes, Base64.DEFAULT);
            updates.put("profileImageBase64", imageBase64);
        }

        // Actualizar los datos en Firestore
        userRef.set(updates)
                .addOnSuccessListener(aVoid -> {
                    progressDialog.dismiss();
                    Toast.makeText(this, "Datos actualizados correctamente", Toast.LENGTH_SHORT).show();
                    Log.d(TAG, "Datos del usuario actualizados en Firestore");
                })
                .addOnFailureListener(e -> {
                    progressDialog.dismiss();
                    Toast.makeText(this, "Error al actualizar los datos", Toast.LENGTH_SHORT).show();
                    Log.e(TAG, "Error al actualizar los datos en Firestore", e);
                });
    }

}
