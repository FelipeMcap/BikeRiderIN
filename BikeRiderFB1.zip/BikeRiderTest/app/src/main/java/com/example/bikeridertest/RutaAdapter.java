package com.example.bikeridertest;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
// Importamos Toast para mostrar mensajes al usuario
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

// Importamos Firebase Auth y Firestore
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.List;
import java.util.Locale;

public class RutaAdapter extends RecyclerView.Adapter<RutaAdapter.RutaViewHolder> {

    private List<Ruta> rutasList;
    private Context context;
    private OnRutaClickListener listener;

    public RutaAdapter(Context context, List<Ruta> rutasList, OnRutaClickListener listener) {
        this.context = context;
        this.rutasList = rutasList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public RutaViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_ruta, parent, false);
        return new RutaViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RutaViewHolder holder, int position) {

        Ruta ruta = rutasList.get(position);

        // Usamos getNombre() en lugar de getTitulo() si la propiedad es 'nombre'
        holder.tvRutaTitulo.setText(ruta.getTitulo());

        String caloriasFormateadas = String.format(Locale.getDefault(), "%.2f kcal", ruta.getCalorias());
        holder.tvCalorias.setText(caloriasFormateadas);

        String distanciaFormateada = String.format(Locale.getDefault(), "%.2f km", ruta.getDistancia());
        holder.tvDistancia.setText(distanciaFormateada);

        holder.btnVerDetalles.setOnClickListener(v -> {
            if (listener != null) {
                listener.onRutaClick(ruta);
            }
        });

        // Listener para el botón "Eliminar Ruta"
        holder.btnEliminarRuta.setOnClickListener(v -> {
            eliminarRuta(ruta.getId(), position);
        });
    }

    @Override
    public int getItemCount() {
        return rutasList.size();
    }

    public interface OnRutaClickListener {
        void onRutaClick(Ruta ruta);
    }

    // Método para eliminar una ruta tanto de Firebase como de la lista local
    private void eliminarRuta(String rutaId, int position) {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user != null) {
            String userId = user.getUid();
            FirebaseFirestore db = FirebaseFirestore.getInstance();
            db.collection("usuarios").document(userId).collection("rutas").document(rutaId)
                    .delete()
                    .addOnSuccessListener(aVoid -> {
                        // Eliminamos la ruta de la lista local y actualizamos la interfaz
                        rutasList.remove(position);
                        notifyItemRemoved(position);
                        notifyItemRangeChanged(position, rutasList.size());
                        Toast.makeText(context, "Ruta eliminada", Toast.LENGTH_SHORT).show();
                    })
                    .addOnFailureListener(e -> {
                        Toast.makeText(context, "Error al eliminar la ruta", Toast.LENGTH_SHORT).show();
                    });
        } else {
            Toast.makeText(context, "Usuario no autenticado", Toast.LENGTH_SHORT).show();
        }
    }

    public static class RutaViewHolder extends RecyclerView.ViewHolder {
        ImageView imageRutaMapa;
        TextView tvRutaTitulo, tvCalorias, tvDistancia;
        Button btnVerDetalles, btnEliminarRuta;

        public RutaViewHolder(@NonNull View itemView) {
            super(itemView);
            imageRutaMapa = itemView.findViewById(R.id.imageRutaMapa);
            tvRutaTitulo = itemView.findViewById(R.id.tvRutaTitulo);
            tvCalorias = itemView.findViewById(R.id.tvCalorias);
            tvDistancia = itemView.findViewById(R.id.tvDistancia);
            btnVerDetalles = itemView.findViewById(R.id.btnVerDetalles);
            btnEliminarRuta = itemView.findViewById(R.id.btnEliminarRuta); // Referencia al botón "Eliminar Ruta"
        }
    }
}


