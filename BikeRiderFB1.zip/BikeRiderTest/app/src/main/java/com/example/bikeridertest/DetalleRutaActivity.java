package com.example.bikeridertest;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.PolylineOptions;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class DetalleRutaActivity extends FragmentActivity implements OnMapReadyCallback {

    private Ruta ruta;
    private GoogleMap mMap;
    private List<LatLng> puntosRuta;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalle_ruta);

        // Obtener la ruta desde el intent
        ruta = (Ruta) getIntent().getSerializableExtra("ruta");

        if (ruta == null) {
            Toast.makeText(this, "No se pudo obtener la ruta", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        puntosRuta = convertirPuntosALatLng(ruta.getPuntos());

        // Configurar el mapa
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);

        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        } else {
            Toast.makeText(this, "No se pudo cargar el mapa", Toast.LENGTH_SHORT).show();
        }

        // Configurar los TextViews
        TextView tvFechaInicio = findViewById(R.id.tvFechaInicio);
        TextView tvFechaFin = findViewById(R.id.tvFechaFin);
        TextView tvDistancia = findViewById(R.id.tvDistancia);
        TextView tvCalorias = findViewById(R.id.tvCalorias);
        TextView tvTiempo = findViewById(R.id.tvTiempo);

        // Calcula el tiempo en milisegundos entre fechaInicio y fechaFin
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault());
        long tiempoEnMilisegundos = 0;
        try {
            Date inicio = sdf.parse(ruta.getFechaInicio());
            Date fin = sdf.parse(ruta.getFechaFin());
            tiempoEnMilisegundos = fin.getTime() - inicio.getTime();
        } catch (ParseException e) {
            e.printStackTrace();
        }

        int segundos = (int) (tiempoEnMilisegundos / 1000) % 60;
        int minutos = (int) ((tiempoEnMilisegundos / (1000 * 60)) % 60);
        int horas = (int) ((tiempoEnMilisegundos / (1000 * 60 * 60)) % 24);

        String tiempoFormateado = String.format(Locale.getDefault(), "%02d:%02d:%02d", horas, minutos, segundos);

        tvFechaInicio.setText(" " + ruta.getFechaInicio());
        tvFechaFin.setText(" " + ruta.getFechaFin());
        tvDistancia.setText(String.format(Locale.getDefault(), "%.2f km", ruta.getDistancia()));

        // Formato de calorías a dos decimales
        String caloriasFormateadas = String.format(Locale.getDefault(), "%.2f kcal", ruta.getCalorias());
        tvCalorias.setText(" " + caloriasFormateadas);

        tvTiempo.setText(" " + tiempoFormateado);
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        mMap = googleMap;

        if (puntosRuta != null && !puntosRuta.isEmpty()) {

            PolylineOptions polylineOptions = new PolylineOptions()
                    .addAll(puntosRuta)
                    .width(10)
                    .color(android.graphics.Color.BLUE);
            mMap.addPolyline(polylineOptions);

            // Centrar el mapa en la ruta
            LatLngBounds.Builder builder = new LatLngBounds.Builder();
            for (LatLng point : puntosRuta) {
                builder.include(point);
            }
            LatLngBounds bounds = builder.build();
            int padding = 100; // Padding para los bordes
            mMap.moveCamera(CameraUpdateFactory.newLatLngBounds(bounds, padding));
        } else {
            Toast.makeText(this, "No hay puntos para mostrar en el mapa", Toast.LENGTH_SHORT).show();
        }
    }

    private List<LatLng> convertirPuntosALatLng(List<Map<String, Double>> puntosMap) {
        List<LatLng> puntos = new ArrayList<>();
        for (Map<String, Double> latLngMap : puntosMap) {
            double lat = latLngMap.get("lat");
            double lng = latLngMap.get("lng");
            puntos.add(new LatLng(lat, lng));
        }
        return puntos;
    }

    public void atras3(View v) {
        Intent intent = new Intent(DetalleRutaActivity.this, MisRutasActivity.class);
        startActivity(intent);
        finish();
    }
}


