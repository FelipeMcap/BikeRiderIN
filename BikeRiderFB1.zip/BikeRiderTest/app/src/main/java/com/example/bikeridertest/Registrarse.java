package com.example.bikeridertest;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class Registrarse extends AppCompatActivity {

    private EditText tvgmail, tvcontra, tvrepcontra;
    private Button registrarcorreo;
    private FirebaseAuth mAuth;
    private ImageView ivTogglePasswordVisibility, ivTogglePasswordVisibilityRepeat;
    private boolean isPasswordVisible = false;
    private boolean isRepeatPasswordVisible = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        tvgmail = findViewById(R.id.tvgmail);
        tvcontra = findViewById(R.id.tvcontra);
        tvrepcontra = findViewById(R.id.tvrepcontra);
        registrarcorreo = findViewById(R.id.registrarcorreo);
        ivTogglePasswordVisibility = findViewById(R.id.ivTogglePasswordVisibility);
        ivTogglePasswordVisibilityRepeat = findViewById(R.id.ivTogglePasswordVisibilityRepeat);

        mAuth = FirebaseAuth.getInstance();

        ivTogglePasswordVisibility.setOnClickListener(v -> {
            isPasswordVisible = !isPasswordVisible;
            if (isPasswordVisible) {
                tvcontra.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                ivTogglePasswordVisibility.setImageResource(R.mipmap.ojoabierto);
            } else {
                tvcontra.setTransformationMethod(PasswordTransformationMethod.getInstance());
                ivTogglePasswordVisibility.setImageResource(R.mipmap.ojocerrao);
            }
            tvcontra.setSelection(tvcontra.getText().length());
        });

        ivTogglePasswordVisibilityRepeat.setOnClickListener(v -> {
            isRepeatPasswordVisible = !isRepeatPasswordVisible;
            if (isRepeatPasswordVisible) {
                tvrepcontra.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                ivTogglePasswordVisibilityRepeat.setImageResource(R.mipmap.ojoabierto);
            } else {
                tvrepcontra.setTransformationMethod(PasswordTransformationMethod.getInstance());
                ivTogglePasswordVisibilityRepeat.setImageResource(R.mipmap.ojocerrao);
            }
            tvrepcontra.setSelection(tvrepcontra.getText().length());
        });

        registrarcorreo.setOnClickListener(v -> {
            String gmail = tvgmail.getText().toString().trim();
            String pass = tvcontra.getText().toString();
            String repass = tvrepcontra.getText().toString();

            if (TextUtils.isEmpty(gmail) || TextUtils.isEmpty(pass) || TextUtils.isEmpty(repass)) {
                Toast.makeText(Registrarse.this, "Todos los campos son requeridos", Toast.LENGTH_SHORT).show();
            } else {
                if (pass.equals(repass)) {
                    if (isValidPassword(pass)) {
                        mAuth.createUserWithEmailAndPassword(gmail, pass)
                                .addOnCompleteListener(task -> {
                                    if (task.isSuccessful()) {
                                        FirebaseUser user = mAuth.getCurrentUser();
                                        Toast.makeText(Registrarse.this, "Registro Exitoso", Toast.LENGTH_SHORT).show();

                                        SharedPreferences preferences = getSharedPreferences("userSession", MODE_PRIVATE);
                                        SharedPreferences.Editor editor = preferences.edit();
                                        editor.putString("userEmail", user.getEmail());
                                        editor.apply();

                                        Intent intent = new Intent(getApplicationContext(), MapaBR.class);
                                        startActivity(intent);
                                        finish();
                                    } else {
                                        Toast.makeText(Registrarse.this, "Error: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                                    }
                                });
                    } else {
                        Toast.makeText(Registrarse.this, "La contraseña debe tener al menos 6 caracteres, una mayúscula y un número", Toast.LENGTH_LONG).show();
                    }
                } else {
                    Toast.makeText(Registrarse.this, "Las contraseñas no coinciden", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private boolean isValidPassword(String password) {
        return password.length() >= 6 && password.matches(".*[A-Z].*") && password.matches(".*\\d.*");
    }
}
