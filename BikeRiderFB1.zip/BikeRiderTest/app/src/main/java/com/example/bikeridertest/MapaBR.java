package com.example.bikeridertest;

import android.Manifest;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.text.InputType;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.android.material.navigation.NavigationView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.QueryDocumentSnapshot;


public class MapaBR extends AppCompatActivity implements OnMapReadyCallback, NavigationView.OnNavigationItemSelectedListener {

    private static final int REQUEST_CODE_LOCATION_PERMISSION = 1;
    private static final double MET_INICIAL = 5.4; // MET inicial para ciclismo moderado
    private double MET = MET_INICIAL;
    private long lastUpdateTimeMillis = 0;
    private float userWeightKg = 70f; // Valor por defecto


    private GoogleMap mMap;
    private FusedLocationProviderClient fusedLocationProviderClient;
    private DrawerLayout drawerLayout;
    private NavigationView navigationView;
    private Toolbar toolbar;

    private boolean isRecording = false;
    private List<LatLng> routePoints = new ArrayList<>();
    private Polyline routeLine;
    // private DBHelper dbHelper;
    private TextView tvCalorias, tvDistancia, tvVelocidad;

    private FirebaseFirestore db;
    private FirebaseAuth mAuth;
    private String userId;



    private double totalCalories = 0;
    private Handler handler = new Handler();
    private long inicioRecorridoTimestamp;
    private long finRecorridoTimestamp;
    private float distanciaRecorrida = 0f;
    private Location ultimaUbicacion;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Verificar si la sesión está activa
        SharedPreferences preferences = getSharedPreferences("userSession", MODE_PRIVATE);
        boolean sesionIniciada = preferences.getBoolean("sesionIniciada", false);

        if (!sesionIniciada) {
            // Si no hay sesión activa, redirigir al LoginActivity
            startActivity(new Intent(this, MainActivity.class));
            finish();
            return;
        }

        setContentView(R.layout.activity_mapa_br);

        //dbHelper = new DBHelper(this);
        db = FirebaseFirestore.getInstance();
        mAuth = FirebaseAuth.getInstance();


        setupToolbar();
        setupNavigationDrawer();
        setupMap();

        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser != null) {
            userId = currentUser.getUid();
        } else {
            Toast.makeText(this, "Usuario no autenticado", Toast.LENGTH_SHORT).show();
            finish();
        }


    tvCalorias = findViewById(R.id.calorie_count);
    tvDistancia = findViewById(R.id.kilometer);

    userWeightKg = preferences.getFloat("userWeight", 70f); // Valor por defecto 70 kg



        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);

        ArrayList<LatLng> recorrido = (ArrayList<LatLng>) getIntent().getSerializableExtra("recorrido");
        if (recorrido != null) {
            mostrarRecorrido(recorrido);
        }
    }

    private void setupToolbar() {
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
    }

    private void setupNavigationDrawer() {
        drawerLayout = findViewById(R.id.main);
        navigationView = findViewById(R.id.nav_view);
        navigationView.bringToFront();

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar,
                R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        navigationView.setNavigationItemSelectedListener(this);
    }

    public void irper(View v) {
        Intent intent = new Intent(MapaBR.this, MiPerfilActivity.class);
        startActivity(intent);
        finish();
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int itemId = item.getItemId();

        if (itemId == R.id.nav_rutas) {
            startActivity(new Intent(this, MisRutasActivity.class));
        } else if (itemId == R.id.nav_perfil) {
            startActivity(new Intent(this, MiPerfilActivity.class));
        } else if (itemId == R.id.nav_progreso) {
            startActivity(new Intent(this, EstadisticasActivity.class));
        } else if (itemId == R.id.nav_cerrar) {
            mostrarDialogoCerrarSesion();
        }

        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }

    private void mostrarDialogoCerrarSesion() {
        new AlertDialog.Builder(this)
                .setTitle("Cerrar sesión")
                .setMessage("¿Estás seguro de que deseas cerrar sesión?")
                .setPositiveButton("Sí", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        logout(); // Llama al método de cierre de sesión
                        Toast.makeText(getApplicationContext(), "Sesión cerrada", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("No", null) // No hacer nada si elige "No"
                .show();
    }


    private void setupMap() {
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.mapa);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }
    }

    private void logout() {
        SharedPreferences preferences = getSharedPreferences("userSession", MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.clear(); // Borra todos los datos guardados
        editor.apply();

        // Redirigir al inicio de sesión
        Intent intent = new Intent(this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }


    public void toggleRecording(View view) {
        Button btnStartStop = findViewById(R.id.btnStartStop);
        if (!isRecording) {
            isRecording = true;
            routePoints.clear();
            totalCalories = 0;
            distanciaRecorrida = 0f;
            ultimaUbicacion = null;
            inicioRecorridoTimestamp = System.currentTimeMillis();
            btnStartStop.setText("Detener Recorrido");
            Toast.makeText(this, "Inicio del recorrido", Toast.LENGTH_SHORT).show();
        } else {
            isRecording = false;
            finRecorridoTimestamp = System.currentTimeMillis();
            guardarRecorrido();
            btnStartStop.setText("Iniciar Recorrido");
            Toast.makeText(this, "Recorrido guardado", Toast.LENGTH_SHORT).show();

            if (routeLine != null) {
                routeLine.remove();
                routeLine = null;
            }
        }
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        mMap.getUiSettings().setZoomControlsEnabled(true);
        mMap.getUiSettings().setMyLocationButtonEnabled(true);

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            mMap.setMyLocationEnabled(true);
            startLocationUpdates();
        } else {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_CODE_LOCATION_PERMISSION);
        }

        CicloviaRoutes cicloviaRoutes = new CicloviaRoutes(mMap);
        cicloviaRoutes.agregarRutasCiclovia();

    }

    private void agregarRutasCiclovia() {
        // Rutas adicionales en el mapa (metodo antiguo)
    }

    private void startLocationUpdates() {
        LocationRequest locationRequest = LocationRequest.create()
                .setInterval(3000)
                .setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            fusedLocationProviderClient.requestLocationUpdates(locationRequest, locationCallback, null);
        }
    }

    private final LocationCallback locationCallback = new LocationCallback() {
        @Override
        public void onLocationResult(@NonNull LocationResult locationResult) {
            if (locationResult == null) return;

            Location location = locationResult.getLastLocation();
            LatLng userLocation = new LatLng(location.getLatitude(), location.getLongitude());

            if (isRecording) {
                routePoints.add(userLocation);

                if (ultimaUbicacion != null) {

                    float distance = ultimaUbicacion.distanceTo(location) / 1000.0f;
                    distanciaRecorrida += distance;

                    long currentTimeMillis = System.currentTimeMillis();
                    long timeDifferenceMillis = currentTimeMillis - lastUpdateTimeMillis;
                    double timeDifferenceHours = timeDifferenceMillis / (1000.0 * 3600.0);

                    // Calcular velocidad en km/h
                    double velocidadKmH = (distance) / timeDifferenceHours;

                    if (tvVelocidad != null) {
                        tvVelocidad.setText(String.format(Locale.getDefault(), "%.2f km/h", velocidadKmH));
                    }

                    // Solo calcular y acumular calorías si la velocidad es mayor o igual a 2 km/h
                    if (velocidadKmH >= 2.0) {
                        // Ajustar MET según la velocidad actual
                        if (velocidadKmH < 16) {
                            MET = 4.0; // Ciclismo lento
                        } else if (velocidadKmH < 19) {
                            MET = 6.8; // Ciclismo moderado
                        } else if (velocidadKmH < 22) {
                            MET = 8.0; // Ciclismo rápido
                        } else {
                            MET = 10.0; // Ciclismo muy rápido
                        }

                        // Calcular calorías quemadas en el intervalo
                        if (timeDifferenceHours > 0) {
                            double caloriesBurnedInInterval = MET * userWeightKg * timeDifferenceHours;
                            totalCalories += caloriesBurnedInInterval;
                        }
                    } else {

                        Toast.makeText(MapaBR.this, "Calculo Detenido", Toast.LENGTH_SHORT).show();

                    }

                    // Actualización de la interfaz
                    if (tvDistancia != null) {
                        tvDistancia.setText(String.format(Locale.getDefault(), "%.2f km", distanciaRecorrida));
                    }
                    if (tvCalorias != null) {
                        tvCalorias.setText(String.format(Locale.getDefault(), "%.2f kcal", totalCalories));
                    }

                    lastUpdateTimeMillis = currentTimeMillis;
                } else {
                    // Primera actualización de ubicación
                    lastUpdateTimeMillis = System.currentTimeMillis();
                }

                ultimaUbicacion = location;

                // Actualiza la línea de la ruta en tiempo real
                if (routeLine != null) routeLine.remove();
                routeLine = mMap.addPolyline(new PolylineOptions().addAll(routePoints).width(15).color(Color.BLUE));
            }

            mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(userLocation, 16));
        }
    };



    private void guardarRecorrido() {
        if (userId == null) {
            Toast.makeText(this, "Usuario no autenticado", Toast.LENGTH_SHORT).show();
            return;
        }

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Nombre del Recorrido");

        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT);
        builder.setView(input);

        builder.setPositiveButton("Guardar", (dialog, which) -> {
            String nombreRecorrido = input.getText().toString().trim();
            if (nombreRecorrido.isEmpty()) {
                nombreRecorrido = "Recorrido " + System.currentTimeMillis();
            }

            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault());
            String fechaInicio = sdf.format(new Date(inicioRecorridoTimestamp));
            String fechaFin = sdf.format(new Date(finRecorridoTimestamp));

            double distanciaKm = distanciaRecorrida;

            // Convertir la lista de LatLng a una lista de mapas para Firestore
            List<Map<String, Double>> puntos = new ArrayList<>();
            for (LatLng punto : routePoints) {
                Map<String, Double> latLngMap = new HashMap<>();
                latLngMap.put("lat", punto.latitude);
                latLngMap.put("lng", punto.longitude);
                puntos.add(latLngMap);
            }

            // Crear un mapa con los datos del recorrido
            Map<String, Object> recorrido = new HashMap<>();
            recorrido.put("nombre", nombreRecorrido);
            recorrido.put("puntos", puntos);
            recorrido.put("calorias", totalCalories);
            recorrido.put("distancia", distanciaKm);
            recorrido.put("fechaInicio", fechaInicio);
            recorrido.put("fechaFin", fechaFin);

            // Guardar en Firestore
            db.collection("usuarios").document(userId)
                    .collection("rutas").add(recorrido)
                    .addOnSuccessListener(documentReference -> {
                        Toast.makeText(MapaBR.this, "Recorrido guardado en Firebase", Toast.LENGTH_SHORT).show();
                    })
                    .addOnFailureListener(e -> {
                        Toast.makeText(MapaBR.this, "Error al guardar el recorrido", Toast.LENGTH_SHORT).show();
                    });
        });

        builder.setNegativeButton("Cancelar", (dialog, which) -> dialog.cancel());
        builder.show();
    }


    public void mostrarRecorrido(List<LatLng> recorrido) {
        PolylineOptions polylineOptions = new PolylineOptions()
                .addAll(recorrido)
                .width(10)
                .color(Color.RED);
        mMap.addPolyline(polylineOptions);
        if (!recorrido.isEmpty()) {
            mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(recorrido.get(0), 16));
        }
    }

    public void abrirmenu(View view) {
        drawerLayout.openDrawer(GravityCompat.START);
    }

    public void activategps(View view) {
        if (!isGPSEnabled()) {
            promptEnableGPS();
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_CODE_LOCATION_PERMISSION);
            } else {
                startLocationUpdates();
                Toast.makeText(this, "GPS Activado", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private boolean isGPSEnabled() {
        LocationManager locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
    }

    private void promptEnableGPS() {
        Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
        startActivity(intent);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CODE_LOCATION_PERMISSION &&
                grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                mMap.setMyLocationEnabled(true);
                startLocationUpdates();
            }
        }
    }

}
